<?php
$telegram_id = "7940217438";
$token_bot = "7576157843:AAGmk9-YAg5UW96r0aevrjKoqyTYp4Esxpc";
?>